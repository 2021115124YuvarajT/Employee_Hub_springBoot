package com.luv2code.springboot.thymeleafdemo.service;

import com.luv2code.springboot.thymeleafdemo.entity.Feedback;

public interface FeedbackService {
    void save(Feedback feedback);
}
